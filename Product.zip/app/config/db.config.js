module.exports = {
url:"mongodb+srv://userdb:Password1@cluster0.1cwczit.mongodb.net/DentistGroupProject?retryWrites=true&w=majority"        
            /*
            Acceso Gmail

                Username: DentistGroupProject@gmail.com

                Clave: Dentistgroupproject123

            */
};
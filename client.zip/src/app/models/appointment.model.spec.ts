import { Appointment } from './appointment.model';

describe('Appointment', () => {
  it('should create an instance', () => {
    expect(new Appointment()).toBeTruthy();
  });
});
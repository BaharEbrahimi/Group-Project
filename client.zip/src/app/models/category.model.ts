export class Category {

  id?: any;
  name?: string;

}

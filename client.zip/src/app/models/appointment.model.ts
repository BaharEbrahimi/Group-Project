export class Appointment {
    id?: any;
    name?: string;
    email?: string;
    phone?: string;
    date?: string;
    time?: string;
    service?: string;
    comments?: string
}
